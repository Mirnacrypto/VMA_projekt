package com.example.SEProjekt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeProjektApplicationTests {

	@Test
	void contextLoads() {
	}

}
