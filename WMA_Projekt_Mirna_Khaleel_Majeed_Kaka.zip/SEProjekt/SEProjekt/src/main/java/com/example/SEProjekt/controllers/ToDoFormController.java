package com.example.SEProjekt.controllers;


import com.example.SEProjekt.Modely.ToDo;
import com.example.SEProjekt.sevices.ToDoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Optional;

@Controller
public class ToDoFormController {
    @Autowired
    private ToDoService toDoService;

    @GetMapping("/create-todo")
    public String showCreateForm(ToDo toDo) {
        return "new-todo";
    }

    @PostMapping("/todo")
    public String createTodo(@Valid ToDo toDo, BindingResult result, Model model) {
        ToDo item = new ToDo();
        item.setDescription(toDo.getDescription());
        item.setIsComplete(toDo.getIsComplete());

        toDoService.save(toDo);
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteToDo(@PathVariable("id") Long id, Model model) {
        ToDo toDo = toDoService
                .getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Todo id:" + id + " nenaslo sa"));

        toDoService.delete(toDo);
        return "redirect:/";
    }


    @GetMapping("/edit/{id}")
    public String showUpdatedForm(@PathVariable("id") Long id, Model model) {
        ToDo toDo = toDoService
                .getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Todo id: " + id + "nenaslo sa"));
        model.addAttribute("todo", toDo);
        return "edit-todo";
    }

    @PostMapping("/todo/{id}")
    public String updateToDo(@PathVariable("id") Long id, @Valid ToDo todo, BindingResult result, Model model) {
        ToDo item= toDoService
                .getById(id)
                .orElseThrow(() -> new IllegalArgumentException("Todo id: " + id + "nenaslo sa"));
        item.setIsComplete(todo.getIsComplete());
        item.setDescription(todo.getDescription());

        toDoService.save(item);

        return "redirect:/";
    }

}
