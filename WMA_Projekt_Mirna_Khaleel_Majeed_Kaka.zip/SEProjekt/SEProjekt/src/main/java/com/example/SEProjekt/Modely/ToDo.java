package com.example.SEProjekt.Modely;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.time.Instant;

@Getter
@Setter
@Entity
@Table (name="todo")
public class ToDo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotBlank(message = "Je potrebny popis")
    private String description;

    private Boolean isComplete;

    private Instant createdAt;

    private Instant updatedAt;

    @Override
    public String toString(){
        return String.format("Todo{id=%d. description='%s', isComplete='%s', createdAr='%s', updatedAt='%s'}",
                id, description, isComplete, createdAt, updatedAt);
    }
}
