package com.example.SEProjekt.controllers;


import com.example.SEProjekt.sevices.ToDoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

    @Autowired
    private ToDoService toDoService;

    @GetMapping("/")
    public ModelAndView index(){
        ModelAndView modelelAndVie =new ModelAndView("index");
        modelelAndVie.addObject("todos", toDoService.getAll());
        return modelelAndVie;
    }

}
