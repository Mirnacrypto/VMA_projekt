package com.example.SEProjekt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeProjektApplication {

	public static void main(String[] args) {

		SpringApplication.run(SeProjektApplication.class, args);
	}

}
