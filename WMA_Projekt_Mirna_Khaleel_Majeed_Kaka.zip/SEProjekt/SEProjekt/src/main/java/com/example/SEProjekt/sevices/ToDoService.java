package com.example.SEProjekt.sevices;


import com.example.SEProjekt.Modely.ToDo;
import com.example.SEProjekt.repositories.ToDoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Optional;

@Service
public class ToDoService {

    @Autowired
    private ToDoRepository toDoRepository;

    public Iterable<ToDo> getAll(){
        return toDoRepository.findAll();
    }

    public Optional<ToDo> getById(Long id){

        return  toDoRepository.findById(id);
    }

    public ToDo save(ToDo toDo){
        if(toDo.getId()==null){
            toDo.setCreatedAt(Instant.now());
        }
        toDo.setUpdatedAt(Instant.now());

        return toDoRepository.save(toDo);
    }

    public void  delete(ToDo toDo){

        toDoRepository.delete(toDo);
    }
}
